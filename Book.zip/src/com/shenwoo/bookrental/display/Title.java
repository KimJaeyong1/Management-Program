package com.shenwoo.bookrental.display;

public class Title {
	public static final String TITLE = "<고양이 책 대여 관리 프로그램>";
}
