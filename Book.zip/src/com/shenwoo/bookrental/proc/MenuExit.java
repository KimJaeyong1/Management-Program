package com.shenwoo.bookrental.proc;

public class MenuExit {
	public void proExit() {
		System.out.println("프로그램을 종료 합니다.");
	}
}
