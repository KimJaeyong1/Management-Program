package com.shenwoo.bookrental.proc;

public class MenuRental {

}
