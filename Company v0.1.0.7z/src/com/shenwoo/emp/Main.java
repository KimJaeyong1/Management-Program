package com.shenwoo.emp;

public class Main {

	public static void main(String[] args) {
		Program program = new Program();
		program.startProgram();
	}
}
