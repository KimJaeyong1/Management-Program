package com.shenwoo.data;

import java.util.HashMap;

public class Supply {
	public void run() {
		HashMap<Integer, String> h = new HashMap<Integer, String>();
		h.put(1, "노트북");
		h.put(1, "책상");
		h.put(1, "의자");
	}
	
}
