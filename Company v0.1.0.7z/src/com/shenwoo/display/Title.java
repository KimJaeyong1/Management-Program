package com.shenwoo.display;

public class Title {
	public static final String TITLE = "*--------------------------------------------------\n        \\o/< 고양이 직원 관리 프로그램 v0.1.0\n--------------------------------------------------*\n";
}
