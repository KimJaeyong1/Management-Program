package com.shenwoo.command;

public class MenuExit {
	public void CommmdExit() {
		System.out.println(
				"Exit===============\n"
				+"[ 프로그램을 종료합니다. ]\n"
				+"================Bye\n");
	}
}
