package com.shenwoo.bookrental.display;

public class Title {
	public static final String TITLE = "*---------------------------------* \n*  <고양이 책 대여 관리 프로그램 v0.3.0>  *\n*---------------------------------*\n";
}
